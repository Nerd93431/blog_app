import logo from './logo.svg';
import './App.css';
import image from './image.png';
import Layout from './pages/Layout';

console.log(image);

function App() {
  return (
    <>
     {/* <Layout />  */}
    <div className="App">
        <header className="App-header">
          <h1> Welcome to the Late-night Philosopher!</h1>
          <h2>The unexamined life is not worth living!</h2>
          <img src={image} alt="image"/>
        </header>
      </div></>
  );
}

export default App;