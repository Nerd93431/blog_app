import React from 'react';
import Button from './button';


const Quiz = () => {
    return (
        <>
            <h1> Sorry it seems this page is down for maintenance! </h1>

    
        </>
        
    );
}

export default  Quiz;