import React from 'react';
import { ReactDOM } from 'react-dom/client';
import reportWebVitals from './reportWebVitals';
import { Link, Route } from 'react-router-dom';
import { BrowserRouter, Routes } from 'react-router-dom';
import { createBrowserRouter, RouterProvider} from "react-router-dom";
import './Main.css';
import Button from './button';

const Main = () => {
    return (
        <>
        <Button message='Click me for accessibility options!'/>
            <h1> Welcome to the Late-Nite Philosopher!</h1>
            <p>Have you ever found yourself unable to sleep and pondering life's big questions?

              Take a look at the link below to an absolutely fantastic podcast series. 
              It's basically like Philospophy for Dummies, or in my case at least :D !
            </p>
            <a
          className="App-link"
          href="https://www.philosophizethis.org/"
          target="_blank"
          rel="noopener noreferrer"
        >
          Click here: Philosophy for Dummies!
        </a>
        </>
        
    );
}


export default Main;
