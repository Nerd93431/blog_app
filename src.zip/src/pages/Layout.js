import { Outlet, Link } from "react-router-dom";
import './Layout.css';


const Layout = () => {
  return (
    <>
      <nav className="navbar"> 
        <ul>
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/main">Main</Link>
          </li>
          <li>
            <Link to="/quiz">Quiz</Link>
          </li>
          <li>
            <Link to="/bigquestions">Big_Questions</Link>
          </li>
        </ul>
      </nav>

      {/* <Outlet /> */}
    </>
  )
};

export default Layout;