import React from 'react';
import Button from './button';

const  Big_Questions = () => {
    return (
        <>
        <Button message='Click me for accessibility options!'/>
            <h1> Would you rather....? </h1>
           
            <p> Have the ability to see 10 minutes into the future</p>
            {/* <Button/> */}
            <Button message='Click me!'/>
            <p>or...</p>
            <p>150 years into the future?</p>
            <Button message='Click me!'/>

            
            
            <p> Have telekinesis (the ability to move things with your mind) </p>
            <Button message='Click me!'/>
            <p>or...</p>
            <p> telepathy (the ability to read minds)?</p>
            <Button message='Click me!'/>

    
        </>
        
    );
}

export default  Big_Questions;