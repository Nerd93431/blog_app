import React from "react";

const Button = ({ message = "" }) => {
    return (
        <button type="button">{message}</button>
    );
}

export default Button;