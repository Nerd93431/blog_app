import React from "react";
import { Link } from "react-router-dom";
const navbar= () =>{
    return (
        <div>
            <li>
                <Link to="/">Main</Link>
            </li>
            <li>
                <Link to="/pages/Quiz">Quiz</Link>
            </li>
            <li>
                <Link to= "/pages/Bigquestions">Big_Questions</Link>
            </li>
        </div>
    );
}
export default navbar;